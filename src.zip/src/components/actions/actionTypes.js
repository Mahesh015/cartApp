export const ADD_TO_CART = 'ADD_TO_CART';
export const ADD_ITEM = 'ADD_ITEM';
export const REMOVE_ITEM = 'REMOVE_ITEM';
export const SUB_QUANTITY = 'SUB_QUANTITY';
export const SORT_ITEMS = 'SORT_ITEMS';